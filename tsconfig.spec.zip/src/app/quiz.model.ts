export class Quiz {
    question!: String;
    answer!: { option: string; correct: boolean; }[];
}
