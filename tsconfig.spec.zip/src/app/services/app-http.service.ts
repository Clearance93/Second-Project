import { Injectable } from '@angular/core';
// import { Http } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppHttpService {

  constructor() { }

  // getHeaders(){
  //   const headers = new Headers();
  //   headers.append('content-Type', 'application/json');
  //   return headers;
  // }

  // get(url: string){
  //   return this.http.get(url);
  // }
}
