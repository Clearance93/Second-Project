//creating an array and passing the number, questions, option and answers
let questions = [
    {
        numb: 1,
        question: "What does HTML stand for?",
        answer: "HyperText Markup Langauge",
        options: [
            "HyperText Mulltiple Langauge",
            "HyperText Markup Langauge",
            "HyperText Makeup Langauge",
            "HyperText Multi Language"
        ]
    },
    {
        numb: 2,
        question: "What does CSS stand for?",
        answer: "Cascading Style Sheet",
        options: [
            "Common Style Sheet",
            "Colourful Style Sheet",
            "Cascading Style Sheet",
            "Computer Style Sheet"
        ]
    },
    {
        numb: 3,
        question: "What does PHP stand for?",
        answer: "Hypertext Preprocessor",
        options: [
            "Hypertext Preprocessor",
            "Hypertext Processor",
            "Hypertext Preprogramming",
            "Hypertext programming"
        ]
    },
    {
        numb: 4,
        question: "What does SQL stand for?",
        answer: "Structured Query Language",
        options: [
            "Stylish Question Language",
            "Stylesheet Query Language",
            "Statement Query Language",
            "Structured Query Language"
        ]
    },
    {
        numb: 5,
        question: "What does XML stand for?",
        answer: "eXtensible Markup Language",
        options: [
            "eXecutable Multiple Langauge",
            "eXtensible Markup Language",
            "eXtra Multi-program Language",
            "eXtra Multiple Language"
        ]
    },
    {
      numb: 6,
      question: "Which of the following is not part of the back-end languages?",
      answer: "HTML",
      options: [
        "HTML",
        "Ruby",
        "Python",
        "Java"
      ]
    },
    {
      numb: 7,
      question: "What is the main primary role of the full stack web developer?",
      answer: "To design user ineraction on websites, developing servers and database for websites functionality and codin.",
      options: [
        "To organize data in the background.",
        "To manage all the applications on the net/site.",
        "To design user ineraction on websites, developing servers and database for websites functionality and codin.",
        "To code, test and analyse all the appications including mobole, desktop and web applications."
      ]
    }
]
